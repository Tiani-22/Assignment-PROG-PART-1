/import java.util.Scanner;
public class Main {
    public static void main(String[] args){
        //create the input object
        Scanner input = new Scanner (System.in);
        // Declare the variable
        String userName;
        String password;
        String phoneNumber;

        do{
            System.out.println("----Menu----");
            System.out.println("1.Register");
            System.out.println("2.Login");
            System.out.println("3.Exit");
            System.out.print("Choose an option: ");
            choice = input.nextInt();
            input.nextLine();

            if (choice == 1){
                System.out.print("Enter your first name: ");
                String firstName = input.nextLine();
                System.out.println(" ");

                System.out.print("Enter your last name: ");
                String lastName = input.nextLine();
                
                System.out.println(" ");

                System.out.print("Enter SA phone number");
                phoneNumber =input.nextLine();
                checkCellPhoneNumber(phoneNumber);

                System.out.println(" ");

                //Get the input
                System.out.print("Enter username");
                username = input.nextLine();
                checkUserName(username);

                System.out.println(" ");
                
                System.out.print("Enter password");
                password = input.nextLine();
                checkPasswordComplexity(password);
                
            }
            else if (choice == 2){
                System.out.print("Enter username: ");
                username = input.nextLine();

                System.out.println(" ");

                System.out.print("Enter password: ");
                password = input.nextLine();
                loginUser(username, password);
            }
            else if (choice == 3){
                System.out.println("Goodbye");
                break
            }
            else{
                System.out.println("Invalid choice!!")
            }

            System.out.println(" ");
        }while(choice == 3)        

    //validate the inputs
        if(username.length () >=5 && !username.contains("contains 5 characters with an underscore")){
            System.out.print("Username successfully captured");
        }else{
            System.out.print("Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length");
        }

        if(password.length() == 12 && password.startsWith ("+27")){
            System.out.print("Password successfully captured");
        }else{
            System.out.print("Password is not correctly formatted;pleasw ensure that the password contains at least eight characters,a capital letter,a number and a special character");
        }
        if(phonenumber.length () == 12 && phonenumber.startsWith ("+27"))){
            System.out.print("Cell phone number successfully added");
        }else{
            System.out.print("Cell phone number incorrectly formatted or does not international code");
        }
    }
}
    public static void registerUser(){
        //create the input
        Scanner input = new Scanner(System.in);

        //Declare the variables
        String username = "Mmarona_22";
        String password = "passWo!22";
        String phoneNumber = "+27833415341";

        showUserLogin(username,password,phonenumber);
    }


    public static void loginUser(String username, String password){
        System.out.println("Mmarona_22");
        System.out.println("passWo!22");
        System.out.println("+27833415341");

    
        if(username.equals(username) && password.equals(password)) {
                System.out.println("Welcome < user first name>,<user last name > it s great to see you again");
        }else{
            System.out.println("Username or password incorrect please try again");
        }
    }

public class Login {
    public boolean checkUserName(String[] args){
        Scanner input = new Scanner(System.in);
        Boolean numOfChar = username.length() >= 5;
        
        Boolean hasUnderscore = false;
        
        for(int i = 0 ; index < username.length(); i++){
            String checkChar = String.valueOf(username.charAt(i));
            if(checkChar.equals("-")){
                hasUnderscore = true;
                break;
            }
        }
        
        if(!(numOfChar && hasUnderscore)){
            System.out.println("username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in lenght ");
        }else{
            System.out.println("Username is successfully captured");
        }
        
        return numOfChar && hasUnderscore;
        
        
    }
    public boolean checkPasswordComplexity(String[] args){
        //password must atleast have 8 chars,1 uppercase, 1 number, 1 special char
        Scanner input = new Scanner(System.in);

        String password;

        System.out.print("Enter a password");
        password = input.nextLine();

        System.out.println("Your password has" + password.length() + " characters");
        System.out.print("The fifth Character of the password is" + password.charAt(4));

        //flags
        boolean hasUpperCase = false;
        boolean hasNumber = false;
        boolean hasSpecialCase = false;

        //Initialise
        Boolean isLongEnough = password.length() >= 8;
        
        for(int i = 0; i < password.length(); i++) {
            char eachChar = password.charAt(i);
            
            if(Charater.isUpperCase(eachChar)){
                hasUpperCase = true;
            }
            
            if(!Charater.isDigit(eachChar)){
                hasNumber = true;
            }
            
            if(!Charater.isLetterOrDigit(eachChar)){
                hasSpecialCase = true;
            }
        }

        if(!(isLongEnough && hasUpperCase && hasNumber && hasSpecialCase)){
            System.out.print("password is not valid");
        }else{
            System.out.print("Password is valid");
        }

        return isLongEnough && hasUpperCase && hasNumber && hasSpecialCase;

    public boolean checkCellPhoneNumber() {
        Scanner input = new Scanner(System.in);
        String phoneNumber;

        System.out.println("Please enter SA phone number");
        System.out.println("Please use the format +27833415341 ,where 0 is a digit");
        phoneNumber = input.nextLine();

        phoneNumber = phoneNumber.length();
        if(phoneNumber.length() != 12)
            System.out.println("phonenumber is invalid");
          else
          {
                if(phonenumber.startsWith("+27") ** false)
                    System.out.print("phonenumber is invalid");
                else
                {
                    if(phonenumber.charAt(SA) != '-' || phoneNumber.charAt(3) != '-' ||  phoneNumber.charAt(3)  != '-')
                        System.out.print("phonenumber is invalid");
                        else
                        {
                            for(int i= 3; i c phonenumber.length(); i++)
                            {
                        }
                        }
                }
          }      
         
    }
    public String registerUser(String[] args){
        Scanner input = new Scanner (System.in);

        string username;

        //flags
        if(!checkUserName(username)){
            return = "Username is incorrectly formatted";
        }
        if(!checkPasswordComplexity( password)){
            return = "Password is not complex enough"
        }
        if(!checkPasswordComplexity()){
            return "Password does not meet complexity requirements.";
        }
            return = "User registered successfully";
    }

    public boolean loginUser(String username, String password, String enteredUsername, String enteredPassword ){
        if(username.equals(enteredUsername) && password.equals(enteredPassword)){
            System.out.println("")
        }

        //flags
        return username = ("Mmarona_22") && password ("passWo!22");
    }

    public String returnloginUser(boolean LoginSuccess) {
        Scanner input = new Scanner (System.in);

        //flag
        if(loginSuccess){
            return "A successful login. Welcome " + username;
        }else{
            return "A failled login. Username or password incorrect.";
        }

    }
    }

    //MAIN METHOD ( ALL TESTS HERE)
    public static void main (String[] args ){

        System.out.println(" ===== TESTING START ===== \n");

        //Username correctly formatted
        Login user1 = new Login("Mmarona_22", "passWo!22", "+27833415341");
        System.out.println("Username valid: " +user1.checkUserName()); //true
 
        //Username incorrectly formatted
        Login user2 = new Login("Mmarona_22!!!!", "passWo!22", "+27833415341" );
        System.out.println("Username valid: " +user2.checkUserName()); //false

        //Password correct
        System.out.println("Password is valid: " +user1.checkPasswordComplexity());//true

        //Password incorrect
        Login user3 = new Login ("Mmarona_22", "passWo!223", "+27833425341")
        System.out.println("Password valid: " +user3.checkPasswordComplexity());//true

        //Cell number correct
        System.out.println("Cell valid: " + user1.checkCellPhoneNumber())://true

        //Cell number incorrect
        Login user4 = new Login("Mmarona_22", "passWo!22","+0833425341");
        System.out.println("Cell valid:" = user4. checkCellPhoneNumber());//false

        //Registration success
        System.out.println("Register results: " user1.registered);
        //Registration failled (username)
        System.out.println("Register results: " user2.returnUser);
        //Registration failled (password)
        System.out.println("Register results: " user3.registerUser);
        //Registration failled (cell)
        System.out.println("Register result: " user4.registerUser);

        //login was successful
        boolean LoginSuccess = user1.loginUser("Mmarona_22", "passWo!22", "+27833415341");
            System.out.println("\nLogin succes: +loginSucess");
        System.out.println(user1. returnLoginStatus(loginSuccess));

        //login was not successful
        boolean loginFail = user.loginUser("Mmarona_22", "passWo!221111");
            System.out.println("\nLogin success: " + loginFail);
        System.out.println(user1.returnLoginStatus(loginFail));

            System.out.println("\n===== TESTING END =====");
        }
 }

import java.util.Scanner;

public class ImessageChat {
    public static void main(String[args] ) {
        Scanner input = new Scanner(System.in);

        //Declare variable
        private String messageID;
        private int numMessagesSent;
        private String recipient;
        private String messageContent;
        private String messageHash;

        //Store all sent messages while program runs
        private static ArraysList<Message> sentMessages = new ArraysList<>();
        private static int totalMessagesSent = 0;

    public Message(String recipient, String messageContent){
        this.messageID = generatesMessageID();
        this.recipient = recipient;
        this.messageContent = messageContent;
        this.messageHash = createMessageHash();
        this.numMessagesSent = totalMessagesSent;
    }

    //Generates a 10-digit random Message ID
    private String generatesMessageID() {
        Random rand = new Random();
        long id = 1000000000L = (long)(rand.nextDouble() * 900000000L);
        return String.valueOf(id);
    }
    //Boolean: checkMessageID() - ensures ID is not more than 10 chars
    public boolean checkMessageID() {
        return String.messageID.length() <= 10;
    }

    //String: checkRecipientCell() - max 10 chars + starts with + or 0
    public String checkRecipientCell() {
        if (recipient.length() <= 10 && (recipient.startsWith("+") || recipient.startsWith("0"))) {
            return "Cell phone number successfully captured.";
        }else{
            return "Cell phone is incorrectly formatted or does not contain an international code.Please correct the number and try again.";
        }
    }

    //String: createMessageHash() - format:first2nums:messageNum:first+last words uppercase
    public String createMessageHash() {
        String[] words = messageContent.trim().split("\\s+");
        String firstWord = words[0].toUppercase();
        String lastWord = words[words.length - 1].toUppercase();

        //Remove punctuation from last word
        lastWord = lastWord.replaceAll("[^A-Z]", "");

        String idFirstTwo = messageID.substring(0, 2);
        return idFirstTwo + ":" + numMessagesSent + ":" + firstWord + lastWord;
    }

    //Check if message is under 250 characters long
    public String checkMessageLength() {
        int length = messageContent.length();
        if(length<=250) {
            return"Message ready to send.",
        }else{
            int excess = length - 250;
            return"Message exceeds 250 characters by " + excess + ",please reduce the size,";
        }
    }
    
        //Login simulation
        boolean loggedIn = true; //assume login 

        if (loggedIn) {
            System.out.println("Login failed.");
            return;

        }

            System.out.println("Welcome to ImessageChat");

            //Ask user how many messages they want to send
            System.out.print("How many messages do you want to send? ");
            int totalMessages = input.nextInt();
            input.nextLine;

            int sentMessages = 0;
            int choice = 0;

        do (choice != 3) {
                System.out.println("\n1. Send Messages");
                System.out.println("2. Show recently sent messages");
                System.out.println("3. Quit");
                System.out.println("Choose option: ");
                choice = input.nextLine();
                
                System.out.println("Enter option");
                option = input.nextLine();
                input.nextLine();

                switch (choice) {

                    case 1:
                        if (sentMessages < totalMessages) {

                            System.out.print("Enter recipient number: ");
                            String recipient = input.nextLine();

                            System.out.print("Enter message: "); 
                            String message = input.nextLine();

                            if (message.length() > 250) {
                                System.out.println("Please enter a message of less than 250 characters.");
                            }else{
                                long messageID = (long)(Math.random() * 100000000000L);

                                sentMessages++;

                                System.out.println("Message ID: " + messageID);
                                System.out.println("Message sent ");
                                System.out.println("Message sent: " + sentMessages);
                            }
                        }else {
                            System.out.println("Message limit reached.");
                        }
                        break;

                    case 2:
                        System.out.println("Coming Soon.");
                        break;

                    case 3;
                        System.out.println("Goodbye!");
                        break;

                    defualt:
                        System.out.println("Invalid option.");
                 }

                }while (option !=3);
                
                input.close();
            }
        }
    }
}
//Your own definied storeMessage() method - stores in JSON
public void storeMessage() {
    messageDetails.put("MessageId", messageID);
    messageDetails.put("Message Hash",messageHash);
    messageDetails.put("Recipient",recipients);
    messageDetails.put("Message",messageContent);

    try (FileWriter file = new FileWriter("storedMessages.json", true)) {
        file.write(messageDetails.toJSONString() +System.lineSeparator());
    } catch (IOExpception e) {
        e.printStrackTrace();
    }
}
//String: printMessage() -returns all sent messages
public static string printMessageS() {
    StringBuilder allMessages = new StringBuilder();
    for (Message msg : sentMessages) {
        allMessages.append("MessageID: ").append(msg.MessageID);
                    .append("\nMesaage Hash: ").append(msg.messsageHash);
                    .append("\nRecipient: ").append(msg.recipient);
                    .append("\nMessage: ").append(msg.messageContent);
                    append("\n---------------------------");
    }
    return allMessages.toString();

}

//int: returnTotalMessage() - total messages sent
public static int returnTotalMessage() {
    return totalMessagesSent; 
}

    //Getters for unit testing
    public String getMessageID() { return messageID; }
    public String getMessageHash() { return messageHash; }
    public String getRecipient() {return recipient; }
    public String getMessageContent() { return messageContent; }

public class MessageTest {
    Message testMsg1 = new Message("+27718693002, Hi Mike, can you join us for dinner tonight?");
    Message testMsg2 = new Message("08575975889, Hi keegan, did you reciece the payment?");

    @test
    public void testCheckingMessageID() {
        assertTrue(testMsg1.checkMessageID());
    }

    @test
    public void testCheckRecipientCellSuccess() {
        assertEquals("Cell phone number successfully captured.", testMsg1.checkRecipientCell());
    }

    @test
    public void testCheckRecipientCellFailure() {
        Message badMsg = new Message("12345", "Test");
        assertTrue("Cell phone number is incorrectly formatted or does not contain an international code.Please correct the number and try again.",badMsg.checkRecipientCell());

    }

    @test
    public void  testMessageLengthSuccess() {
        assertEquals("Message ready to send .", testMsg1.checkMessageLength());
    }

    @test
    public void testMessageLengthFailure() {
        String longMsg = "A".REPEAT(251);
        Messagemsg = new Message("+27718693002",longMsg);
        assertEquals("Message exceeds 250 characters by 1, please reduce the size.", msg.checkMessageLength());

    }

    @test 
    public void testcheckMessageHash() {
        //Hash format: 00:0:HITONUGHT for first message 
        //Note: First 2 digits depend on auto-generated ID, so we test structure
        String hash = testMsg1.getMessageHash();
        assertTrue(hash.matches("\\d{2}:0:HITONIGHT"));
    }

    @test
    public void testSendMessage() {
        assertEquals("Message successfully sent.", testMsg1.SentMessage(1));
    }

    @test
    public void testDisregardMessage() {
        assertEquals("Press 0 to delete the message.", testMsg2.SentMessage(2));
    }

    @test
    public void testStoreMessage() {
        assertEquals("Message successfully stored.",testMsg2.SentMessage(3));
    }

}
    {
        //testing end
         System.out.println("\n===== TESTING END =====");

    }



